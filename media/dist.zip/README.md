# JaDa
JaDa (Ja~~kob~~ + Da~~niel~~) is a template, which delivers responsive predefined html elements with the help of Less and Grunt
