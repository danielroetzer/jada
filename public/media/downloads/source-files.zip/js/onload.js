/*

 */


//Show/hide elements on the first visit
//of the website
window.onload=function(){
    //panel
    $("#panel1").show();
    $("#panel2").hide();
    $("#panel3").hide();

    //library
    $("#lib1").show();
    $("#lib2").hide();
    $("#lib3").hide();

    $("#lib-active1").show();
    $("#lib-active2").hide();
    $("#lib-active3").hide();
};